/*
 * Copyright © 2010 Canonical, Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Authors: Chase Douglas <chase.douglas@canonical.com>
 *
 */

#ifndef _GESTURE_H_
#define _GESTURE_H_

#ifdef HAVE_DIX_CONFIG_H
#include <dix-config.h>
#endif

#include "inputstr.h"

/* This is the last Gesture event supported by the server. If you add
 * events to the protocol, the server will not support these events until
 * this number here is bumped.
 */
#define GESTURELASTEVENT     63
#define GESTUREMASKSIZE      (GESTURELASTEVENT/8 + 1) /* no of bits for masks */

extern _X_EXPORT int GestureReqCode;

/**
 * Attached to the devPrivates of each client. Specifies the version number as
 * supported by the client.
 */
typedef struct _GestureClientRec {
        int major_version;
        int minor_version;
} GestureClientRec, *GestureClientPtr;

typedef struct _GestureClients *GestureClientsPtr;

/**
 * This struct stores the Gesture event mask for each client.
 *
 * Each window that has events selected has at least one of these masks. If
 * multiple client selected for events on the same window, these masks are in
 * a linked list.
 */
typedef struct _GestureClients {
    GestureClientsPtr  next; /**< Pointer to the next mask */
    XID                resource; /**< id for putting into resource manager */
    /** Gesture event masks. One per device, each bit is a mask of (1 << type) */
    unsigned char      gestureMask[EMASKSIZE][GESTUREMASKSIZE];
} GestureClients;

typedef struct _GestureMasks {
    GestureClientsPtr   clients;
    unsigned char       mask[GESTUREMASKSIZE];
} GestureMasks;

extern int GestureClientGone(WindowPtr pWin, XID id);
extern void DeleteWindowFromGestureEvents(WindowPtr pWin);

#endif /* _GESTURE_H_ */
