/*
 *  version.h
 */

#define KOBS_NG_MAJOR		0
#define KOBS_NG_MINOR		0
#define KOBS_NG_SUBMINOR	1
#define KOBS_NG_VERSION		((KOBS_NG_MAJOR<<16)|\
				 (KOBS_NG_MINOR<<8)|\
				  KOBS_NG_SUBMINOR)
#define KOBS_NG_VERSION_STR	"0.0.1"

