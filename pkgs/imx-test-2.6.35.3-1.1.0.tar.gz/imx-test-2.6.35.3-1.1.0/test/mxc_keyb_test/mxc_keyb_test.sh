#!/bin/sh

#keypad test is evtest

evtest /dev/input/keyboard0
