static int e[] = { '\'', '\"', '\?', '\\',
                   '\a', '\b', '\f', '\n', '\r', '\t', '\v', };
static char *s = "\'\"\?\\ \a\b\f\n\r\t\v";
/*
 * check-name: Character escape sequences
 */
