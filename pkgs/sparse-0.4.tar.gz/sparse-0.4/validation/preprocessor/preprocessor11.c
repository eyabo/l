#define A(1) x
#define B(x
#define C(x,
#define D(,)
#define E(__VA_ARGS__)
#define F(x+
#define G(x...,
#define H(x...,y)
#define I(...+
#define J(x,y)
