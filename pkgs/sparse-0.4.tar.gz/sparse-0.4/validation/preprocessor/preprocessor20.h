#ifdef X
B
#endif
#ifndef Y
A
#endif
